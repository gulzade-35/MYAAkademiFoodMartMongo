# Datta Able Free Tailwind Admin Template

#### Preview

 - [Demo](https://themewagon.github.io/DattaAble/)

#### Download
 - [Download from ThemeWagon]( https://themewagon.com/themes/DattaAble)
 
 
## Getting Started

Clone from Github 
```
git clone https://github.com/codedthemes/datta-able-free-tailwind-admin-template.git
```
*no other dependencies required to run the Datta Able Template*
## Author

Design and code is completely written by CodedThemes's design and development team.  


## License

 - Design and Code is Copyright &copy; [CodedThemes](https://www.codedthemes.com)
 - Licensed cover under [MIT]
 - Distributed by [ThemeWagon](https://themewagon.com)

